package com.osiansoftware.usermanagementsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UsermanagementsystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
